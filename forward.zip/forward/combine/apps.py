from django.apps import AppConfig


class CombineConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'combine'
