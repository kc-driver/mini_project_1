from django.contrib import admin
from mini.models import UserProfileInfo, User

# Register your models here.
admin.site.register(UserProfileInfo)